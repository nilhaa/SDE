
import sqlite3

# Connect to the SQLite database
db_path = 'train_seating.db'

# Seat allocation logic
def book_seats(num_seats):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Try to find consecutive seats in the same row
    cursor.execute("SELECT row_number, COUNT(*) FROM Seats WHERE status='available' GROUP BY row_number")
    available_seats = cursor.fetchall()

    # Step 2: Find a row with enough available seats
    for row, available in available_seats:
        if available >= num_seats:
            # Book seats in the same row
            cursor.execute("SELECT seat_id FROM Seats WHERE row_number=? AND status='available' LIMIT ?", (row, num_seats))
            seats_to_book = cursor.fetchall()
            for seat_id in seats_to_book:
                cursor.execute("UPDATE Seats SET status='booked' WHERE seat_id=?", (seat_id[0],))
            conn.commit()
            conn.close()
            return [seat_id[0] for seat_id in seats_to_book]

    # Step 3: Book nearby seats if no row can accommodate all seats
    cursor.execute("SELECT seat_id FROM Seats WHERE status='available' LIMIT ?", (num_seats,))
    seats_to_book = cursor.fetchall()
    for seat_id in seats_to_book:
        cursor.execute("UPDATE Seats SET status='booked' WHERE seat_id=?", (seat_id[0],))
    
    conn.commit()
    conn.close()
    return [seat_id[0] for seat_id in seats_to_book]

# Display the seating arrangement
def display_seating():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT row_number, seat_number, status FROM Seats ORDER BY row_number, seat_number")
    seats = cursor.fetchall()

    coach_layout = ""
    for row in range(1, 13):
        row_seats = [seat for seat in seats if seat[0] == row]
        for seat in row_seats:
            status = "B" if seat[2] == 'booked' else "A"
            coach_layout += f"{status} "
        coach_layout += "\n"

    conn.close()
    return coach_layout

# Booking example
booked_seats = book_seats(4)
print("Seats booked:", booked_seats)
print(display_seating())
